Synthetic fixture; not official BIS data.
